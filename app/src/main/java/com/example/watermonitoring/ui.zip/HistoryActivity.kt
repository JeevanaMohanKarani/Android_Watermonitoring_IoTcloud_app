package com.example.watermonitoring

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.watermonitoring.ui.theme.WatermonitoringTheme
import com.google.firebase.database.*

data class HistoryEntry(
    val timestamp: String = "",
    val data: String = ""
)

class HistoryActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            WatermonitoringTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    HistoryScreen()
                }
            }
        }
    }
}

@Composable
fun HistoryScreen() {
    var historyList by remember { mutableStateOf(listOf<HistoryEntry>()) }

    val dbRef = FirebaseDatabase.getInstance().reference.child("history")

    LaunchedEffect(true) {
        dbRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<HistoryEntry>()
                for (child in snapshot.children) {
                    val timestamp = child.child("timestamp").getValue(String::class.java) ?: "N/A"
                    val data = child.child("data").getValue(String::class.java) ?: "No Data"
                    list.add(HistoryEntry(timestamp, data))
                }
                historyList = list.sortedByDescending { it.timestamp } // recent first
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("Firebase", "Error loading history: ${error.message}")
            }
        })
    }

    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {

        Text("📜 Historical Data", style = MaterialTheme.typography.headlineSmall)
        Divider(modifier = Modifier.padding(vertical = 8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(historyList) { entry ->
                HistoryCard(entry)
            }
        }
    }
}

@Composable
fun HistoryCard(entry: HistoryEntry) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text("🕒 ${entry.timestamp}", style = MaterialTheme.typography.titleSmall)
            Text("📊 ${entry.data}", style = MaterialTheme.typography.bodyLarge)
        }
    }
}

